package com.hackathon.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightontimeApplicationTests {

	@Test
	void contextLoads() {
	}

}
