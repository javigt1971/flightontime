package com.hackathon.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightontimeApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightontimeApplication.class, args);
	}

}
